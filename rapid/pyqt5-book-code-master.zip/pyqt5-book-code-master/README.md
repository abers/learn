pyqt5-book-code
===============

This work is about porting the source code of book, Rapid GUI Programming with python and Qt, from PyQt4 to PyQt5.
